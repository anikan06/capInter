
export interface UserDetails {
    name: string;
    age: number;
    gender: string;
    hobbies: string
    verified: boolean;
} 